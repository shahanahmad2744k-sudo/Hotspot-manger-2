package com.hotspotmanager

data class ConnectedDevice(
    val name: String,
    val ipAddress: String,
    val macAddress: String
)